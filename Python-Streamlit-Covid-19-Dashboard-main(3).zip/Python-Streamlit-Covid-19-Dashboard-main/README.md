# WHO's COVID-19 Weekly Epidemiological Update 
#### Created a dashboard (https://pooja97-us-covid-19-main-2-5j1lns.streamlitapp.com/)  for monitoring Covid-19 cases and deaths worldwide using streamlit, plotly, and plotly express. 
#### Data is collected from the USAfacts.org. 
